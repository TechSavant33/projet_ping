<?php
  // Paramètre de connexion à la BDD (à créer)
  $host="localhost";
  $login="root";
  $passwd="";
  $dbname="projet_ping";
?>